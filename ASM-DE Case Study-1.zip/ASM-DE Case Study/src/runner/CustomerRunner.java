package runner;

 import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dao.CustomerDaoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerRunner {
	
	Scanner input = new Scanner(System.in);

	public void method1() throws SQLException {
		String ssn;
		String Patternssn = "\\d{9}?";  //Takes only numbers for ssn input
		
		
		String selection1 = "\nPlease enter a valid Social Security Number \n" + "";
		System.out.print(selection1);
		ssn = input.next();
		
		
		while ((ssn.length() != 9) || !ssn.matches(Patternssn))
		{
			System.out.print("*************************************\n");
			System.out.print("***You have entered invalid Number***\n");
			System.out.print("*************************************\n");
			System.out.print(selection1);
			ssn = input.next();
		}
		

		CustomerDaoImpl CustDaoimpl1 = new CustomerDaoImpl();
		CustDaoimpl1.CheckCustomer(ssn);
	}

	public void method2() throws SQLException {
		
		String CUST_ZIP, CUST_PHONE; 
		String FIRST_NAME, MIDDLE_NAME, LAST_NAME, CREDIT_CARD_NO, APT_NO, STREET_NAME, CUST_CITY, CUST_STATE;
		String CUST_COUNTRY, CUST_EMAIL, SSN;
		int menu = 0;
		boolean Validmenu = true;
		String ValidSSN = "\\d{9}?";
		String Validcustinfo = "^[a-zA-Z\\\\s]*$";
		String ValidZipcode = "\\d{5}?";
		String ValidPhonenum = "\\d{7}?";
		String ValidEmail =  "^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$";
				
		String expression = "AK|AL|AR|AZ|CA|CO|CT|DC|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NC|ND|NE|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY|ak|al|ar|az|ca|co|ct|dc|de|fl|ga|hi|ia|id|il|in|ks|ky|la|ma|md|me|mi|mn|mo|ms|mt|nc|nd|ne|nh|nj|nm|nv|ny|oh|ok|or|pa|ri|sc|sd|tn|tx|ut|va|vt|wa|wi|wv|wy";


		String selection1 = "\nPlease enter a valid Social Security Number to modify the record \n" + "";
		System.out.print(selection1);
		SSN = input.next();

		while ((SSN.length() != 9) || !SSN.matches(ValidSSN)) {
			System.out.print("*************************************\n");
			System.out.print("***You have entered invalid Number***\n");
			System.out.print("*************************************\n");
			System.out.print(selection1);
			SSN = input.next();
		}	
		String selection = "\nSelect the number from the following menu you would like to modify. \n \n" 
				+ "1. Name Fields \n"
				+ "2. Address \n"
				+ "3. Phone \n"
				+ "4. Email \n"; 
	
	do {	
		
		try {
		System.out.print(selection);
		menu = input.nextInt();
		input.nextLine();

		while (menu < 1 || menu > 4) 
		{
			System.out.print("******************************************\n");
			System.out.print("*** You have entered invalid selection ***\n");
			System.out.print("******************************************\n");
			System.out.print(selection);
			menu = input.nextInt();
			input.nextLine();
	
			}
		Validmenu = true;
		}
		catch(InputMismatchException e)
		{
			System.out.println("Invalid menu");
			System.out.println("Please enter only numbers from 1 to 4");
			input.next();
			Validmenu = false;
		}
		}
		while(Validmenu == false);

		switch (menu) {
		case 1:
			System.out.print("Enter First Name: ");
			FIRST_NAME = input.next();
			while(!FIRST_NAME.matches(Validcustinfo)) //Validating for the proper first name
			{
				System.out.println("****************************");
				System.out.println("\n****INVALID FIRST NAME****\n");
				System.out.println("****************************");
				System.out.println("Please enter a valid First Name");
				FIRST_NAME = input.next();
			}
			
			System.out.print("Enter Middle Name: ");
			MIDDLE_NAME = input.next();
			while(!MIDDLE_NAME.matches(Validcustinfo)) // Validating for the proper middle name
			{
				System.out.println("****************************");
				System.out.println("\n****INVALID MIDDLE NAME****\n");
				System.out.println("****************************");
				System.out.println("Please enter a valid Middle Name");
				MIDDLE_NAME = input.next();
			}
			
			System.out.print("Enter Last Name: ");
			LAST_NAME = input.next();
			while(!LAST_NAME.matches(Validcustinfo)) //Validating for the proper last name
			{
				System.out.println("****************************");
				System.out.println("\n****INVALID LAST NAME****\n");
				System.out.println("****************************");
				System.out.println("Please enter a valid Last Name");
				LAST_NAME = input.next();
			}
			
			CustomerDaoImpl CustDaoimpl2a = new CustomerDaoImpl();
			CustDaoimpl2a.ModifyCustomerName(SSN, FIRST_NAME, MIDDLE_NAME, LAST_NAME);
		 	break; 
		 	
		case 2:
			System.out.print("Enter Apartment NO: ");
			APT_NO = input.nextLine();
			System.out.print("Enter Street Name: ");
			STREET_NAME = input.nextLine();
			System.out.print("Enter City: ");
			CUST_CITY = input.nextLine();
			while (!CUST_CITY.matches(Validcustinfo)) // Validating for the correct city
			{
				System.out.println("******************************************");
				System.out.println("\n****You have entered an invalid city****\n");
				System.out.println("******************************************");
				System.out.println("Please enter a valid city");
				CUST_CITY = input.nextLine();
				
			}
			System.out.print("Enter State: ");
			CUST_STATE = input.nextLine();
	        CharSequence inputStr = CUST_STATE;
            Pattern pattern = Pattern.compile(expression);
            Matcher matcher = pattern.matcher(inputStr);
     
            while (!matcher.matches()) {
		          System.out.print("************************************\n");
		          System.out.print("***You have entered invalid State***\n");
		          System.out.print("************************************\n");
		          System.out.print("Enter State: ");
		          CUST_STATE = input.nextLine();
		          inputStr = CUST_STATE;
                  pattern = Pattern.compile(expression);
                  matcher = pattern.matcher(inputStr);
	        }
			
			System.out.print("Enter Country: ");
			CUST_COUNTRY = input.nextLine();
			while (!CUST_COUNTRY.matches(Validcustinfo)) // Validating for the Correct Country
			{
				System.out.println("******************************************");
				System.out.println("\n****You have entered an invalid country****\n");
				System.out.println("******************************************");
				System.out.println("Please enter a valid Country");
				CUST_COUNTRY = input.nextLine();
				
			}
			System.out.print("Enter Zip: ");
			CUST_ZIP = input.next();
			
			while ((CUST_ZIP.length() != 5) || !CUST_ZIP.matches(ValidZipcode)){
				System.out.print("****************************************\n");
				System.out.print("***You have entered invalid zip code ***\n");
				System.out.print("****************************************\n");
				System.out.print("Enter valid Zip: ");
				CUST_ZIP = input.next();
			}	
		 	CustomerDaoImpl CustDaoimpl2b = new CustomerDaoImpl();
		 	CustDaoimpl2b.ModifyCustomerAdd(SSN, APT_NO,STREET_NAME, CUST_CITY, CUST_STATE, CUST_COUNTRY, CUST_ZIP);
		 	break;
		 	
		case 3:
			System.out.print("Enter 7 digit Phone number: ");
			CUST_PHONE = input.next();
			
			while ((CUST_PHONE.length() != 7) || !CUST_PHONE.matches(ValidPhonenum))
			{
				System.out.print("********************************************\n");
				System.out.print("***You have entered invalid Phone number ***\n");
				System.out.print("********************************************\n");
				System.out.print("Enter a valid Phone number:  ");
				CUST_PHONE = input.next();
			}	
		 	CustomerDaoImpl CustDaoimpl2c = new CustomerDaoImpl();
		 	CustDaoimpl2c.ModifyCustomerPhone(SSN, CUST_PHONE);
		 	break;
		 	
		case 4:
			System.out.print("Enter Email: ");
			CUST_EMAIL = input.next();
			while (!CUST_EMAIL.matches(ValidEmail))
			{
				System.out.print("********************************************\n");
				System.out.print("***You have entered invalid EMAIL ***\n");
				System.out.print("********************************************\n");
				System.out.print("Enter Valid Email id:  ");
				CUST_EMAIL = input.next();
			}	
			
			CustomerDaoImpl CustDaoimpl2d = new CustomerDaoImpl();
		 	CustDaoimpl2d.ModifyCustomerEmail(SSN, CUST_EMAIL);
		 	break;
		default:
			System.out.println("It is not a correct #");
		}	
	}
	
	public void method3() throws SQLException {
		String creditCard;
		int month = 0, year=0;
		String ValidCreditcard = "\\d{16}?";
		boolean validmonth = true;
		boolean validyear = true;
		
		String selection1 = "\nPlease enter a valid Credit Card Number \n" + "";
		System.out.print(selection1);
		creditCard = input.next();
		
//validating for the creditcard not to accept characters
		
		while ((creditCard.length() != 16) || !creditCard.matches(ValidCreditcard)) {
			System.out.print("*************************************\n");
			System.out.print("***You have entered invalid Credit card Number***\n");
			System.out.print("*************************************\n");
			System.out.print(selection1);
			creditCard = input.next();
		}
		
		// validating for the month		
	do {

	try {   
		
		String selection2 = "\nPlease enter a valid Month as MM \n" + "";
		System.out.print(selection2);
		month = input.nextInt();
		input.nextLine();
						
		while (month < 1 || month > 12) 
				{
			System.out.print("************************************\n");
			System.out.print("***You have entered invalid Month***\n");
			System.out.print("************************************\n");
			System.out.print(selection2);
			month = input.nextInt();
		}
		validmonth = true;
	}
	catch(InputMismatchException e) {
		System.out.println("\nInvalid month\n");			
		input.next();
		validmonth = false;
	}
	}
	while(validmonth == false);
	
	// validating for the year	
	do {
		try {   
	
		String selection3 = "\nPlease enter a valid year between " + "1950 to 2018 as YYYY  \n" + "";
		System.out.print(selection3);
		year = input.nextInt();
		
		while (year < 1900 || year > 2018) {
			System.out.print("***********************************\n");
			System.out.print("***You have entered invalid Year***\n");
			System.out.print("***********************************\n");
			System.out.print(selection3);
			year = input.nextInt();

		}
		validyear = true;
		}
		catch(InputMismatchException e) {
			System.out.println("\nInvalid year\n");
			input.next();
			validyear = false;
			}
	}
	while(validyear == false);
		
		CustomerDaoImpl CustDaoimpl3 = new CustomerDaoImpl();
		CustDaoimpl3.GenerateBill(creditCard, month, year);
		}

		
	public void method4() throws SQLException {
		String ssn,Validssn = "\\d{9}?";
		int fromYear=0, toYear=0, fromMonth=0, toMonth=0, fromDay=0, toDay=0;
		boolean validyear = true;
		boolean validmonth = true;
		boolean validday = true;
		
		String selection1 = "\nPlease enter a valid Social Security Number \n" + "";
		System.out.print(selection1);
		ssn = input.next();
		
// validating the ssn not to accept characters
		
		while ((ssn.length() != 9)|| !ssn.matches(Validssn)) {  
			System.out.print("*************************************\n");
			System.out.print("***You have entered invalid Number***\n");
			System.out.print("*************************************\n");
			System.out.print(selection1);
			ssn = input.next();
		}
		
// Validating for the "from" year		
	do {
		try {     

		String selection2 = "\nPlease enter a valid year between " + "1950 to 2018 as YYYY from  \n" + "";
		System.out.print(selection2);
		fromYear = input.nextInt();
		while (fromYear < 1950 || fromYear > 2018) {
			System.out.print("***********************************\n");
			System.out.print("***You have entered invalid Year***\n");
			System.out.print("***********************************\n");
			System.out.print(selection2);
			fromYear = input.nextInt();
		}
		validyear = true;
	}
	catch(InputMismatchException e) {
		System.out.println("\nInvalid year\n");
		input.next();
		validyear = false;
		}
}
while(validyear == false);
	
// validating for the "from" month
	
		do {
			try {
				
			String selection4 = "\nPlease enter a valid Month as MM from \n" + "";
			System.out.print(selection4);
			fromMonth = input.nextInt();
			
			while (fromMonth < 1 || fromMonth > 12) {
				System.out.print("************************************\n");
				System.out.print("***You have entered invalid Month***\n");
				System.out.print("************************************\n");
				System.out.print(selection4);
				fromMonth = input.nextInt();
			}
	    validmonth = true;
			}
	    catch(InputMismatchException e) {
		System.out.println("Invalid month");
		input.next();
		validmonth = false;
	}
			}
			while(validmonth == false);
	
// validating for the "from" day
				do {
		try {		
				String selection6 = "\nPlease enter a valid Day as DD from \n" + "";
				System.out.print(selection6);
				fromDay = input.nextInt();
				
					while (fromDay < 1 || fromDay > 30) {
					System.out.print("************************************\n");
					System.out.print("***You have entered invalid Day ***\n");
					System.out.print("************************************\n");
					System.out.print(selection6);
					fromDay = input.nextInt();
				}
					validday = true;
		}
		catch(InputMismatchException e) {
			System.out.println("Invalid day");
			input.next();
			validday = false;
		}
				}
		while(validday == false);
	
// validating for the "to" year
	do {
		try {    

	String selection3 = "\nPlease enter a valid year between " + "1950 to 2018 as YYYY to \n" + "";
	System.out.print(selection3);
	toYear = input.nextInt();
	
	while (toYear < 1950 || toYear > 2018) {
		System.out.print("***********************************\n");
		System.out.print("***You have entered invalid Year***\n");
		System.out.print("***********************************\n");
		System.out.print(selection3);
		fromYear = input.nextInt();
	}
	validyear = true;
}
catch(InputMismatchException e) {
	System.out.println("\nInvalid year\n");
	input.next();
	validyear = false;
	}
}
while(validyear == false);
	
	

//validating for the "to" month
	
	do {
		try {
		String selection5 = "\nPlease enter a valid Month as MM to \n" + "";
		System.out.print(selection5);
		toMonth = input.nextInt();
		
		while (toMonth < 1 || toMonth > 12) {
			System.out.print("************************************\n");
			System.out.print("***You have entered invalid Month***\n");
			System.out.print("************************************\n");
			System.out.print(selection5);
			fromMonth = input.nextInt();
		}
validmonth = true;
		}
		catch(InputMismatchException e) {
			System.out.println("Invalid month");
			input.next();
			validmonth = false;
		}
	}
		while(validmonth == false);
		


//validating for the "to" day

do {
	try {
			
			String selection7 = "\nPlease enter a valid Day as DD to \n" + "";
			System.out.print(selection7);
			toDay = input.nextInt();
			
			while (toDay < 1 || toDay > 31) {
				System.out.print("************************************\n");
				System.out.print("***You have entered invalid Day ***\n");
				System.out.print("************************************\n");
				System.out.print(selection7);
				fromDay = input.nextInt();
			}
			validday = true;
	}
	catch(InputMismatchException e) {
		System.out.println("Invalid day");
		input.next();
		validday = false;
	}
	
}
	while(validday == false);

		CustomerDaoImpl CustDaoimpl4 = new CustomerDaoImpl();
		CustDaoimpl4.DisplayTrans(ssn, fromYear, toYear, fromMonth, toMonth, fromDay, toDay);
	}
	}
	
