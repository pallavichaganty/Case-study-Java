package runner;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dao.TransactionDaoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.SQLException;

public class TransactionRunner {
	
	private String [] validTranstionTypes = {
		"education", "entertainment", "grocery", "gas", "bills", "test", "healthcare"
	};
	private final String[] validStateCodes = {
		"ak", "al", "ar", "az", "ca", "co", "ct", "dc", "de", "fl", 
		"ga", "hi", "ia", "id", "il", "in", "ks", "ky", "la", "ma", 
		"md", "me", "mi", "mn", "mo", "ms", "mt", "nc", "nd", "ne", 
		"nh", "nj", "nm", "nv", "ny", "oh", "ok", "or", "pa", "ri", 
		"sc", "sd", "tn", "tx", "ut", "va", "vt", "wa", "wi", "wv", 
		"wy"	
	};
	
	Scanner input = new Scanner(System.in);
	TransactionDaoImpl txDao = new TransactionDaoImpl();
	
	public void method1() throws SQLException {
		try {
			int zip = this.captureValidInteger("", "ZIP", "Enter a valid Zip Code (5-digits): ", "Invalid Zip Code, please try again");
			int month = this.captureValidInteger("", "MONTH", "Enter a month (1-12)", "Invalid month, please try again");
			int year = this.captureValidInteger("", "YEAR", "Enter a valid year (1950-2018)", "Invalid year, please try again");
			txDao.getbyZipcode(String.valueOf(zip), month, year);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	} 

	public void method2() throws SQLException {
		try {
		String inputMessage = "Please enter a transaction type from this list (" + String.join(", ", this.validTranstionTypes) + "):";
		String transactionType = this.captureValidString("", "TRANSACTIONTYPE", inputMessage, "Invalid transaction type, please try again");
		TransactionDaoImpl TXDaoimpl2 = new TransactionDaoImpl();
		TXDaoimpl2.getbyType(transactionType);
		} catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	
	public void method3() throws SQLException {
		try {
			String inputMessage = "Please enter a valid state code from this list (" + String.join(", ", this.validStateCodes) + "): ";
			String state = this.captureValidString("", "STATECODE", inputMessage, "Invalid state code, please try again");
			TransactionDaoImpl TXDaoimpl3 = new TransactionDaoImpl();
			TXDaoimpl3.getbyState(state);
		} catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	private boolean isValidStateCode(String entered_state) {
		return Arrays.stream(this.validStateCodes).anyMatch(entered_state.toLowerCase()::equals);
	}
	
	private boolean isValidTranstionType(String entered_type) {
		return Arrays.stream(this.validTranstionTypes).anyMatch(entered_type.toLowerCase()::equals);
	}
	
	private boolean isValidZip(String entered_zip) {
		if(entered_zip.length() == 5) {
			try {
				int zip = Integer.parseInt(entered_zip);
				if(zip > 9999) {
					return true;
				}
			} catch(Exception ex) {
				return false;
			}
		}
		return false;
	}
	
	private boolean isValidMonth(String month) {
		try {
			int int_month = Integer.parseInt(month);
			return (int_month > 0 && int_month < 13) ? true : false;
		} catch(Exception ex) {
			return false;
		}
	}
	
	private boolean isValidYear(String year) {
		try {
			int int_year = Integer.parseInt(year);
			return (int_year > 1949 && int_year < 2019) ? true : false;
		} catch(Exception ex) {
			return false;
		}
	}
	
	private int captureValidInteger(String entry, String inputType, String inputMessage, String errorMessage) throws Exception {
		int returnValue = Integer.MIN_VALUE;
		boolean isValid = false;
		while(!isValid) {
			if(entry.length() > 0) {
				switch(inputType) {
					case "ZIP":
						isValid = this.isValidZip(entry);
						break;
					case "MONTH":
						isValid = this.isValidMonth(entry);
						break;
					case "YEAR":
						isValid = this.isValidYear(entry);
						break;
					default:
						throw new Exception("Invalid inputType");
				}
			}
			if(!isValid) {
				if(entry.length() > 0) { System.out.println(errorMessage + "\n"); }
				System.out.println(inputMessage);
				entry = input.next();
			} else {
				returnValue = Integer.parseInt(entry);
			}
		}
		return returnValue;
	}
	
	private String captureValidString(String entry, String inputType, String inputMessage, String errorMessage) throws Exception {
		String returnValue = "";
		boolean isValid = false;
		while(!isValid) {
			if(entry.length() > 0) {
				switch(inputType) {
					case "TRANSACTIONTYPE":
						isValid = this.isValidTranstionType(entry);
						break;
					case "STATECODE":
						isValid = this.isValidStateCode(entry);
						break;
					default:
						throw new Exception("Invalid entry");
				}
			}
			if(!isValid) {
				if(entry.length() > 0) { System.out.println(errorMessage + "\n"); }
				System.out.println(inputMessage);
				entry = input.next();
			} else {
				returnValue = entry;
			}
		}
		return returnValue;
	}

	
	
}